import unittest
from project.student import Student


class TestStudent(unittest.TestCase):

    def setUp(self):
        self.student = Student("Patlak")
        self.student_courses = Student("Kiuftak", {"math": ["some note"]})

    def test_correct_init(self):
        self.assertEqual("Patlak", self.student.name)
        self.assertEqual({}, self.student.courses)
        self.assertEqual({"math": ["some note"]}, self.student_courses.courses)

    def test_enroll_add_notes_to_existing_course(self):
        result = self.student_courses.enroll("math", ["second note"])
        self.assertEqual("second note", self.student_courses.courses["math"][1])
        self.assertEqual("Course already added. Notes have been updated.", result)

    def test_add_notes_to_not_existing_course_without_third_param(self):
        # using empty student 'Patlak' to add course and notes
        result = self.student.enroll("math", ["math note"])
        self.assertEqual("Course and course notes have been added.", result)

    def test_add_notes_to_not_existing_course_with_third_param(self):
        # using empty student 'Patlak' to add course and add_course_notes
        result = self.student.enroll("math", ["math note"], "Y")
        self.assertEqual("Course and course notes have been added.", result)

    def test_add_new_course_without_notes(self):
        # using empty student 'Patlak' to add course and add_course_notes
        result = self.student.enroll("math", ["math note"], "N")
        self.assertEqual(0, len(self.student.courses["math"]))
        self.assertEqual("Course has been added.", result)

    def test_add_notes(self):
        result = self.student_courses.add_notes("math", "second note")
        self.assertEqual(2, len(self.student_courses.courses["math"]))
        self.assertEqual("Notes have been updated", result)
        with self.assertRaises(Exception) as ex:
            self.student.add_notes("geography", "blabla")
        self.assertEqual("Cannot add notes. Course not found.", str(ex.exception))

    def test_leave_course(self):
        result = self.student_courses.leave_course("math")
        self.assertEqual(0, len(self.student.courses))
        self.assertEqual("Course has been removed", result)
        with self.assertRaises(Exception) as ex:
            self.student.leave_course("geography")
        self.assertEqual("Cannot remove course. Course not found.", str(ex.exception))


if __name__ == "__main__":
    unittest.main()
